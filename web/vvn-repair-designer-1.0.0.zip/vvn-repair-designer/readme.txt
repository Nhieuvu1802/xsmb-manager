=== VVN Repair Designer ===
Contributors: laptopvvn
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Extension tạo trang chủ dịch vụ sửa laptop/điện thoại, form đặt lịch và quản lý phiếu sửa chữa.

== Cài đặt ==
1. Vào Plugin > Cài plugin > Tải plugin lên.
2. Chọn file vvn-repair-designer.zip và kích hoạt.
3. Vào Cài đặt > VVN Repair để thay hotline, Zalo, địa chỉ, giờ làm việc và màu sắc.
4. Plugin tự tạo và đặt trang “Sửa chữa laptop & điện thoại” làm trang chủ.

Lưu ý cho website LAPTOP VVN hiện tại: xóa hoặc đổi hai dòng DISALLOW_FILE_EDIT và DISALLOW_FILE_MODS trong functions.php của theme appro nếu WordPress chặn cài plugin.
