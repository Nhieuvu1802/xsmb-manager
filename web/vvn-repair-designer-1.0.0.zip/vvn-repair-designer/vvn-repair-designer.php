<?php
/**
 * Plugin Name: VVN Repair Designer
 * Description: Thiết kế trang chủ và quản lý yêu cầu sửa chữa laptop, điện thoại cho LAPTOP VVN.
 * Version: 1.0.0
 * Author: LAPTOP VVN
 * Text Domain: vvn-repair
 */

if (!defined('ABSPATH')) exit;

define('VVN_REPAIR_VERSION', '1.0.0');
define('VVN_REPAIR_URL', plugin_dir_url(__FILE__));

function vvn_repair_defaults() {
    return array(
        'phone' => '0900 000 000',
        'zalo' => '0900000000',
        'address' => 'Cập nhật địa chỉ cửa hàng trong Cài đặt → VVN Repair',
        'hours' => '08:00–20:00, Thứ 2–Chủ nhật',
        'primary' => '#0b57d0',
        'accent' => '#ff6b00',
    );
}

function vvn_repair_options() {
    return wp_parse_args(get_option('vvn_repair_options', array()), vvn_repair_defaults());
}

add_action('init', function () {
    register_post_type('vvn_repair_order', array(
        'labels' => array('name' => 'Phiếu sửa chữa', 'singular_name' => 'Phiếu sửa chữa', 'menu_name' => 'Phiếu sửa chữa', 'add_new_item' => 'Thêm phiếu sửa chữa'),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-admin-tools',
        'supports' => array('title'),
        'capability_type' => 'post',
        'map_meta_cap' => true,
    ));
});

register_activation_hook(__FILE__, function () {
    $page = get_page_by_path('sua-chua-laptop-dien-thoai');
    if (!$page) {
        $page_id = wp_insert_post(array(
            'post_title' => 'Sửa chữa laptop & điện thoại',
            'post_name' => 'sua-chua-laptop-dien-thoai',
            'post_content' => '[vvn_repair_home]',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    } else {
        $page_id = $page->ID;
    }
    if ($page_id && !is_wp_error($page_id)) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', (int) $page_id);
    }
    flush_rewrite_rules();
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('vvn-repair', VVN_REPAIR_URL . 'assets/repair.css', array(), VVN_REPAIR_VERSION);
    wp_enqueue_script('vvn-repair', VVN_REPAIR_URL . 'assets/repair.js', array(), VVN_REPAIR_VERSION, true);
});

function vvn_repair_services() {
    return array(
        array('💻', 'Sửa laptop', 'Không nguồn, mất hình, treo máy, lỗi bàn phím, bản lề, mainboard.'),
        array('📱', 'Sửa điện thoại', 'Thay màn hình, pin, chân sạc, camera, loa, mic và xử lý vào nước.'),
        array('🧹', 'Vệ sinh & bảo dưỡng', 'Vệ sinh máy, thay keo tản nhiệt, tối ưu nhiệt độ và hiệu năng.'),
        array('💾', 'Cài đặt & cứu dữ liệu', 'Cài Windows/phần mềm, diệt mã độc, nâng cấp SSD/RAM, cứu dữ liệu.'),
        array('🔍', 'Kiểm tra miễn phí', 'Chẩn đoán rõ lỗi và báo giá trước khi sửa, không tự ý phát sinh.'),
        array('🛡️', 'Bảo hành minh bạch', 'Ghi rõ linh kiện, chi phí, thời hạn bảo hành và trạng thái xử lý.'),
    );
}

function vvn_repair_form_submit() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['vvn_repair_action'])) return '';
    if (!isset($_POST['vvn_repair_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vvn_repair_nonce'])), 'vvn_repair_submit')) {
        return '<div class="vvn-alert vvn-error">Phiên gửi đã hết hạn. Vui lòng tải lại trang.</div>';
    }
    $name = sanitize_text_field(wp_unslash($_POST['customer_name'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['customer_phone'] ?? ''));
    $device = sanitize_text_field(wp_unslash($_POST['device'] ?? ''));
    $problem = sanitize_textarea_field(wp_unslash($_POST['problem'] ?? ''));
    if (!$name || !preg_match('/^[0-9+ .()-]{8,20}$/', $phone) || !$device || !$problem) {
        return '<div class="vvn-alert vvn-error">Vui lòng nhập đủ thông tin và kiểm tra số điện thoại.</div>';
    }
    $id = wp_insert_post(array('post_type' => 'vvn_repair_order', 'post_status' => 'publish', 'post_title' => $name . ' – ' . $device));
    if (is_wp_error($id)) return '<div class="vvn-alert vvn-error">Chưa thể lưu yêu cầu. Vui lòng gọi hotline.</div>';
    foreach (array('name' => $name, 'phone' => $phone, 'device' => $device, 'problem' => $problem, 'status' => 'Mới tiếp nhận') as $key => $value) {
        update_post_meta($id, '_vvn_' . $key, $value);
    }
    return '<div class="vvn-alert vvn-success">Đã nhận yêu cầu #' . (int) $id . '. Kỹ thuật viên sẽ liên hệ sớm.</div>';
}

add_shortcode('vvn_repair_home', function () {
    $o = vvn_repair_options();
    $notice = vvn_repair_form_submit();
    ob_start(); ?>
    <main class="vvn-site" style="--vvn-primary:<?php echo esc_attr($o['primary']); ?>;--vvn-accent:<?php echo esc_attr($o['accent']); ?>">
      <section class="vvn-hero">
        <div class="vvn-wrap vvn-hero-grid">
          <div><span class="vvn-kicker">LAPTOP VVN • KỸ THUẬT TẬN TÂM</span><h1>Sửa laptop & điện thoại<br><em>nhanh, rõ giá, đúng lỗi</em></h1><p>Kiểm tra kỹ trước khi sửa, báo giá minh bạch và bảo hành rõ ràng. Hỗ trợ tận nơi theo khu vực.</p><div class="vvn-actions"><a class="vvn-btn primary" href="tel:<?php echo esc_attr(preg_replace('/\D+/', '', $o['phone'])); ?>">Gọi <?php echo esc_html($o['phone']); ?></a><a class="vvn-btn ghost" href="#dat-lich">Đặt lịch kiểm tra</a></div><div class="vvn-trust"><span>✓ Báo giá trước</span><span>✓ Không tráo linh kiện</span><span>✓ Có phiếu bảo hành</span></div></div>
          <aside class="vvn-quick"><strong>Tiếp nhận trong 60 giây</strong><p>Mô tả lỗi để được tư vấn sơ bộ.</p><a href="#dat-lich">Gửi yêu cầu ngay <span>→</span></a><small><?php echo esc_html($o['hours']); ?></small></aside>
        </div>
      </section>
      <section class="vvn-section"><div class="vvn-wrap"><div class="vvn-heading"><span>DỊCH VỤ</span><h2>Một nơi xử lý mọi vấn đề thiết bị</h2><p>Từ kiểm tra cơ bản đến sửa chữa phần cứng chuyên sâu.</p></div><div class="vvn-services">
      <?php foreach (vvn_repair_services() as $s): ?><article><i><?php echo esc_html($s[0]); ?></i><h3><?php echo esc_html($s[1]); ?></h3><p><?php echo esc_html($s[2]); ?></p></article><?php endforeach; ?>
      </div></div></section>
      <section class="vvn-process"><div class="vvn-wrap"><div class="vvn-heading light"><span>QUY TRÌNH</span><h2>4 bước minh bạch</h2></div><ol><li><b>01</b><strong>Tiếp nhận</strong><span>Ghi nhận thiết bị và tình trạng</span></li><li><b>02</b><strong>Kiểm tra</strong><span>Chẩn đoán và gửi báo giá</span></li><li><b>03</b><strong>Sửa chữa</strong><span>Chỉ thực hiện khi khách đồng ý</span></li><li><b>04</b><strong>Bàn giao</strong><span>Kiểm tra, thanh toán, bảo hành</span></li></ol></div></section>
      <section id="dat-lich" class="vvn-section"><div class="vvn-wrap vvn-form-grid"><div><div class="vvn-heading left"><span>ĐẶT LỊCH</span><h2>Gửi yêu cầu kiểm tra</h2><p>Thông tin được lưu thành phiếu trong trang quản trị. Bạn có thể gọi trực tiếp nếu cần xử lý gấp.</p></div><div class="vvn-contact"><p><b>Hotline</b><br><?php echo esc_html($o['phone']); ?></p><p><b>Địa chỉ</b><br><?php echo esc_html($o['address']); ?></p><p><b>Giờ làm việc</b><br><?php echo esc_html($o['hours']); ?></p></div></div>
      <form class="vvn-form" method="post"><?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php wp_nonce_field('vvn_repair_submit', 'vvn_repair_nonce'); ?><input type="hidden" name="vvn_repair_action" value="1"><label>Họ và tên<input name="customer_name" required autocomplete="name"></label><label>Số điện thoại<input name="customer_phone" required inputmode="tel" autocomplete="tel"></label><label>Thiết bị<input name="device" required placeholder="VD: Dell Inspiron 15, iPhone 13"></label><label>Mô tả lỗi<textarea name="problem" required rows="4" placeholder="Máy đang gặp tình trạng gì?"></textarea></label><button class="vvn-btn primary" type="submit">Gửi yêu cầu sửa chữa</button><small>Bằng việc gửi form, bạn đồng ý để cửa hàng liên hệ tư vấn.</small></form></div></section>
      <a class="vvn-float vvn-call" aria-label="Gọi hotline" href="tel:<?php echo esc_attr(preg_replace('/\D+/', '', $o['phone'])); ?>">☎</a><a class="vvn-float vvn-zalo" aria-label="Chat Zalo" target="_blank" rel="noopener" href="https://zalo.me/<?php echo esc_attr(preg_replace('/\D+/', '', $o['zalo'])); ?>">Zalo</a>
    </main><?php
    return ob_get_clean();
});

add_action('admin_menu', function () {
    add_options_page('VVN Repair', 'VVN Repair', 'manage_options', 'vvn-repair', 'vvn_repair_settings_page');
});
add_action('admin_init', function () {
    register_setting('vvn_repair_group', 'vvn_repair_options', array('sanitize_callback' => function ($input) {
        $d = vvn_repair_defaults();
        return array(
            'phone' => sanitize_text_field($input['phone'] ?? $d['phone']), 'zalo' => sanitize_text_field($input['zalo'] ?? $d['zalo']),
            'address' => sanitize_text_field($input['address'] ?? $d['address']), 'hours' => sanitize_text_field($input['hours'] ?? $d['hours']),
            'primary' => sanitize_hex_color($input['primary'] ?? '') ?: $d['primary'], 'accent' => sanitize_hex_color($input['accent'] ?? '') ?: $d['accent'],
        );
    }));
});
function vvn_repair_settings_page() { if (!current_user_can('manage_options')) return; $o = vvn_repair_options(); ?>
  <div class="wrap"><h1>VVN Repair Designer</h1><p>Cấu hình thông tin hiển thị trên trang chủ sửa chữa.</p><form method="post" action="options.php"><?php settings_fields('vvn_repair_group'); ?><table class="form-table"><tr><th>Hotline</th><td><input class="regular-text" name="vvn_repair_options[phone]" value="<?php echo esc_attr($o['phone']); ?>"></td></tr><tr><th>Số Zalo</th><td><input class="regular-text" name="vvn_repair_options[zalo]" value="<?php echo esc_attr($o['zalo']); ?>"></td></tr><tr><th>Địa chỉ</th><td><input class="large-text" name="vvn_repair_options[address]" value="<?php echo esc_attr($o['address']); ?>"></td></tr><tr><th>Giờ làm việc</th><td><input class="regular-text" name="vvn_repair_options[hours]" value="<?php echo esc_attr($o['hours']); ?>"></td></tr><tr><th>Màu chính</th><td><input type="color" name="vvn_repair_options[primary]" value="<?php echo esc_attr($o['primary']); ?>"></td></tr><tr><th>Màu nhấn</th><td><input type="color" name="vvn_repair_options[accent]" value="<?php echo esc_attr($o['accent']); ?>"></td></tr></table><?php submit_button(); ?></form><p><b>Shortcode:</b> <code>[vvn_repair_home]</code></p></div>
<?php }

add_filter('manage_vvn_repair_order_posts_columns', function ($c) { return array('cb'=>$c['cb'], 'title'=>'Khách hàng / thiết bị', 'vvn_phone'=>'Điện thoại', 'vvn_problem'=>'Mô tả lỗi', 'vvn_status'=>'Trạng thái', 'date'=>'Ngày gửi'); });
add_action('manage_vvn_repair_order_posts_custom_column', function ($column, $id) { if (strpos($column, 'vvn_') === 0) echo esc_html(get_post_meta($id, '_' . $column, true)); }, 10, 2);

