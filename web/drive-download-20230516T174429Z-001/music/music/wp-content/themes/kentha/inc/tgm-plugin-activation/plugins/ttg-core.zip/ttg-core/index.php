<?php  
/* Silence is golden */
