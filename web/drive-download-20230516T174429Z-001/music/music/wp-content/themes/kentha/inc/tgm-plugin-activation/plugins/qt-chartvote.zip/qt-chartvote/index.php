<?php  
// Silence is golden;