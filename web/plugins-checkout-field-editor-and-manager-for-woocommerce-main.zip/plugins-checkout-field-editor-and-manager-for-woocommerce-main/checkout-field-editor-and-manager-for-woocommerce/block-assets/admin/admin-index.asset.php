<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '6f3dd2a521118a57c4e4');
